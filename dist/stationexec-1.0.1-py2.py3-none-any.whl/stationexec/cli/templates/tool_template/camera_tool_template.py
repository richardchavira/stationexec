# Copyright 2004-present Facebook. All Rights Reserved.

# @lint-ignore-every PYTHON3COMPATIMPORTS1

# @nolint
"""
{{tool_name}} Camera Tool
"""
from stationexec.logger import log
from stationexec.toolbox.camerabase import CameraBase

version = "0.1"
dependencies = ["numpy", "opencv-python"]
default_configurations = {
    "target_sn": 0,
    "decimation": 1,
    "frames_per_second": 15,
}


class {{tool_class}}(CameraBase):
    def __init__(self, arg1, arg2=None, arg3=10, **kwargs):
        """
        Setup camera driver

        :param str target_sn:
        :param tuple width_height:
        :param int decimation:
        :param dict kwargs: All leftover args from call; passed to parent class
        """
        super({{tool_class}}, self).__init__(**kwargs)
        self.target_sn = str(target_sn)
        self.width, self.height = width_height
        self.decimation = decimation
        self.cam = None

        self.stream_color_mode = cv2.COLOR_BAYER_BG2RGB

    def initialize(self):
        """ Prepare tool for operation """
        pass

    def verify_status(self):
        """ Check that tool is online; attempt to repair if not. Called every 5 seconds. """
        # Check if tool is healthy

        if not self.is_online:
            # Perform corrective actions to reset or re-initialize the tool
            if self.cam is not None:
                self.stop_capture()
                # self.initialize()

    def shutdown(self):
        """ Cleanup tool for program shutdown """
        self.stop_capture()
        if self.cam is not None:
            # Close camera references
            pass

    def on_ui_command(self, command, **kwargs):
        """ Command received from UI """
        if command == "action1":
            log.info("Performing Action 1")
            self.action1()
        elif command == "action2":
            log.info("Performing Action 2")
        elif command == "action3":
            log.info("Performing Action 3 with arguments: {0}".format(kwargs))
        elif command == "start_video":
            self.begin_video_stream()
        elif command == "stop_video":
            self.end_video_stream()

    def start_capture(self, message="Capturing"):
        """
        Start video/constant capture on the camera

        :param str message: Optional status message to indicate camera in capture mode

        :return: None
        """
        if not self.is_capturing:
            # Request camera begin continuous capture
            self.set_status_message(message)
            self.is_capturing = True

    def stop_capture(self):
        """
        Stop the video/constant capture

        :return: None
        """
        if self.cam is not None:
            # Disable continuous capture on camera
            pass
        self.reset_status_message()
        self.is_capturing = False

    def capture_stream_image(self):
        # Capture image from camera stream and return it as a np.array
        return np.array(image)

    def action1(self):
        log.info("Action 1 is Starting")
