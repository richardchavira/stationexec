from stationexec.version import version


__version__ = version