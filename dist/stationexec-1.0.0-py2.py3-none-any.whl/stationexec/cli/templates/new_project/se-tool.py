#!/usr/bin/env python
# Copyright 2004-present Facebook. All Rights Reserved.

# @lint-ignore-every PYTHON3COMPATIMPORTS1

from stationexec.cli.cli_tools import cli_tool

if __name__ == "__main__":
    cli_tool()
